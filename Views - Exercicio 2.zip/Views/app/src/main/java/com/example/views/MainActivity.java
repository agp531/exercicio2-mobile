package com.example.views;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.views.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_main);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnLimpar.setOnClickListener(this);
        binding.btnExibir.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btnLimpar){
            //Toast.makeText(this, "Limpar", Toast.LENGTH_SHORT).show();
            binding.edtNome.setText("");
            binding.edtEmail.setText("");
            binding.edtTel.setText("");
            binding.swtNotificacao.setChecked(false);
            binding.chkMusice.setChecked(false);
            binding.chkCinema.setChecked(false);
            binding.chkEsporte.setChecked(false);
            binding.chkGastro.setChecked(false);
        }else if(view.getId() == R.id.btnExibir){
            Toast.makeText(this, "Exibir", Toast.LENGTH_LONG).show();
        }
    }
}